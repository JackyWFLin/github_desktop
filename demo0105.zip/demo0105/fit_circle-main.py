#!/usr/bin/env python
# coding: utf-8

# In[14]:


from CCD_Measure import *
import cv2
import shutil


# In[15]:

import sys
import numpy as np
from scipy import optimize
from matplotlib import pyplot as plt, cm, colors

def calc_R(x,y, xc, yc):
    """ calculate the distance of each 2D points from the center (xc, yc) """
    return np.sqrt((x-xc)**2 + (y-yc)**2)

def f_error(c, x, y):
    """ calculate the algebraic distance between the data points and the mean circle centered at c=(xc, yc) """
    Ri = calc_R(x, y, *c)
    return Ri - Ri.mean()

def leastsq_circle(x,y):
    # coordinates of the barycenter
    x_m = np.mean(x)
    y_m = np.mean(y)
    center_estimate = x_m, y_m
    center, ier = optimize.leastsq(f_error, center_estimate, args=(x,y))
    xc, yc = center
    Ri       = calc_R(x, y, *center)
    R        = Ri.mean()
    residu   = np.sum((Ri - R)**2) / len(Ri)
    
    print("before fit",x_m,y_m)
    print("after fit",xc,yc)
    
    print("ERROR:", np.sum(Ri) / len(Ri))
    print("residu:", residu)
    return xc, yc, R, residu


        
def plot_data_circle(x,y, xc, yc, R, ff):
    print(ff)
    f = plt.figure( facecolor='white', figsize=(10, 10))  #figsize=(7, 5.4), dpi=72,
    plt.axis('equal')

    theta_fit = np.linspace(-np.pi, np.pi, 180)

    x_fit = xc + R*np.cos(theta_fit)
    y_fit = yc + R*np.sin(theta_fit)
    plt.plot(x_fit, y_fit, 'b-' , label="fitted circle", lw=2)
    plt.plot([xc], [yc], 'bD', mec='y', mew=1)
    plt.xlabel('x')
    plt.ylabel('y')   
    # plot data
    plt.plot(x, y, 'r-.', label='data', mew=1)

    plt.legend(loc='best',labelspacing=0.1 )
    plt.grid()
    plt.title('Least Squares Circle')
    print("/".join(ff.split('/')[0:-1]) + '/circle.jpg')
    plt.savefig("/".join(ff.split('/')[0:-1]) + '/demo/circle.jpg')
    
    
def plot_data_circle_demo(x, y, ff):
    i = 1
    count = int(len(x) / 100) + 1
    while(i<=100):
        end_i = i * count
        if end_i >= len(x):
            end_i = len(x)
        
        f = plt.figure( facecolor='white', figsize=(10, 10))
        plt.axis('equal')
        plt.xlabel('x')
        plt.ylabel('y')   
        # plot data
        plt.plot(x[0:end_i], y[0:end_i], 'g-' , label="Raw", lw=1)
        plt.grid()
        plt.title('Raw Data Circle')
        plt.legend(loc='best',labelspacing=0.1 )
        plt.savefig("/".join(ff.split('/')[0:-1]) + '/demo/circle/' + str(i) + '.jpg')
        i += 1


# In[45]:


def get_cal_value(img_path, demo_img_path):    
    img_ori = cv2.imread(img_path)
    img_gray = cv2.cvtColor(img_ori, cv2.COLOR_BGR2GRAY)
    ret1, img_binary = cv2.threshold(img_gray, 40, 255, cv2.THRESH_BINARY)
    t1 = []
    for i in range(img_binary.shape[0]):
        r = img_binary[i]
        t1.append(str(len(r[r == 0])* 7.04 / 1000))
    
    scale = 0.1
    img_new = cv2.resize(img_ori, (int(img_ori.shape[1] * scale),int(img_ori.shape[0] * scale)), interpolation=cv2.INTER_AREA)
    cv2.imwrite(demo_img_path, cv2.rotate(img_new, cv2.ROTATE_90_COUNTERCLOCKWISE))
    
    
    return t1


# In[46]:


def init_demo(path):
    
    demo_path = path + "/demo"
    if os.path.exists(demo_path):
        shutil.rmtree(demo_path)
        
    if os.path.exists(path + "/raw.txt"):
        os.remove(path + "/raw.txt")
        
    os.makedirs(demo_path)
    os.makedirs(demo_path + "/circle")
    os.makedirs(demo_path + "/crack")
    


# In[49]:


if __name__ == '__main__':
    path = sys.argv[1]
    #path = 'demo0105'
    
    print(path)
    init_demo(path)
    img_file_list = [i for i in os.listdir(path) if '.bmp' in i ]
    for img_file in img_file_list:
        value_list = get_cal_value(path + '/' + img_file, path + '/demo/raw.bmp')
        f = open(path + '/raw.txt', 'w')
        f.write('\n'.join(value_list))
        f.close()


    result = []
    group = 360
    file_list = [i for i in os.listdir(path) if '.txt' in i]
    for f in file_list:    
        ccd = CCD_Measure(path + '/' + f, group)
        ccd.measure()
        plot_data_circle_demo(ccd.x_raw, ccd.y_raw,path + '/' + f)
        xc, yc, R, residu = leastsq_circle(ccd.x, ccd.y)
        plot_data_circle(ccd.x, ccd.y, xc, yc, R, path + '/' + f)
        result.append(ccd.meas_value + ccd.result + [residu])


    r = [ccd.result[4], ccd.result[3] * 1000, residu * 1000, ccd.result[2] * 1000]
    r = [str(round(i,4)) for i in r]
    f = open(path + '/demo/data.txt', 'w')
    f.write(','.join(r))
    f.close()
    